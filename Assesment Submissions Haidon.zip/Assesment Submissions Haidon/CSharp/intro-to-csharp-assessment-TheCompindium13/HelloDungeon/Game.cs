﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HelloDungeon
{
    //Basic weapon structure
    struct Weapon
    {
        public string WeaponName;
        public float WeaponDamage;
    }

    //The class that holds the basic game
    class Game
    {
        //Basic variables
        bool GameOver;
        int Currentscene = 0;
        int Currentenemyindex;

        
        //The Enemies
        Character CrazedBandit;
        Character Gatorsaw;
        Character SaneBandit;
        Character[] Enemies;

        //Player Character
        Player PlayerCharacter;

        //Dog
        Dog DogCharacter;

        //Intro to story
        void IntroScene()
        {

            Console.WriteLine("Tales of a Well Traveled Courier");

            Console.WriteLine(@" _____          _                          __             _    _          _   _     _____                                 _              _    _____                          _               ");
            Console.WriteLine(@"|_   _|        | |                        / _|           | |  | |        | | | |   |_   _|                               | |            | |  /  __ \                        (_)              ");
            Console.WriteLine(@"  | |    __ _  | |   ___   ___     ___   | |_     __ _   | |  | |   ___  | | | |     | |    _ __    __ _  __   __   ___  | |   ___    __| |  | /  \/   ___    _   _   _ __   _    ___   _ __ ");
            Console.WriteLine(@"  | |   / _` | | |  / _ \ / __|   / _ \  |  _|   / _` |  | |/\| |  / _ \ | | | |     | |   | '__|  / _` | \ \ / /  / _ \ | |  / _ \  / _` |  | |      / _ \  | | | | | '__| | |  / _ \ | '__|");
            Console.WriteLine(@"  | |  | (_| | | | |  __/ \__ \  | (_) | | |    | (_| |  \  /\  / |  __/ | | | |     | |   | |    | (_| |  \ V /  |  __/ | | |  __/ | (_| |  | \__/\ | (_) | | |_| | | |    | | |  __/ | |   ");
            Console.WriteLine(@"  \_/   \__,_| |_|  \___| |___/   \___/  |_|     \__,_|   \/  \/   \___| |_| |_|     \_/   |_|     \__,_|   \_/    \___| |_|  \___|  \__,_|   \____/  \___/   \__,_| |_|    |_|  \___| |_|   ");
            Console.ReadLine();
            Console.Clear();
            Console.ReadLine();
            Console.WriteLine("Welcome what is your name?");
            Console.Write(">");
            
            
            PlayerCharacter.SetName(Console.ReadLine());
            string Namechoice = PlayerCharacter.Getinput("Greetings Courier... " + PlayerCharacter.GetName() + " This is your name correct", "Yes", "No");
            
            if (Namechoice == "1")
            {
                Console.WriteLine("Alright lets continue");
                //Change current scene to ChangeWeaponScene();
                Currentscene = 9;
            }
            else if (Namechoice == "2")
            {
                Console.WriteLine("Oh my bad what is it again?");
                //Change current scene to IntroScene();
                Currentscene = 0;
            }
            else
            {
                Console.WriteLine("Error");
                Console.ReadKey(true);
                Console.WriteLine(">");
            }
        }



        //This Is The Scene You See When Just Starting The Story
        void BreakScene()
        {
            //Worldbuilding
            Console.Clear();
            Console.WriteLine("'Welcome to the Lone Star Courier Service " + PlayerCharacter.GetName() + " glad to have you aboard.'");
            Console.ReadLine();
            Console.WriteLine("You dust the sands of the desert from your stiched up and raggedy old pants.");
            Console.WriteLine("Hitching a ride with a traveling caravan heading towards New Opealousas.");
            Console.WriteLine("You have been tasked by your employer to deliver a package too");
            Console.WriteLine("an area in the southwest wasteland.");
            Console.WriteLine("You are to be paid on delivery. Your delivery is in the town Lafayette");
            Console.WriteLine("The caravan is stopping for a moment to refuel.");
            Console.ReadLine();

            string playerchoice = PlayerCharacter.Getinput("To pass the time you...", "Talk with a caravan hand", "Take a nap", "End Game", "Change Weapon");
            Console.ReadKey(true);

            if (playerchoice == "1")
            {
                Console.Clear();
                Console.WriteLine("You learn a local legend about a strange armored devil.");
                //Change current scene to FightSceneProlouge();
                Currentscene = 3;

            }
            else if (playerchoice == "2")
            {
                Console.Clear();
                Console.WriteLine("You lay down in one of the empty carts and doze off for longer then you thought.");
                //Change current scene to FightSceneProlouge();
                Currentscene = 3;
            }
            else if (playerchoice == "3")
            {
                //Change current scene to GameOverScene();
                Currentscene = 4;
            }
            else if (playerchoice == "4")
            {
                //Change current scene to ChangeWeaponScene();
                Currentscene = 9;
            }
            else
            {
                Console.WriteLine("Error");
                Console.ReadKey(true);
                Console.WriteLine(">");
            }
        }

        //This Is The Scene You See When You Enter The Town
        void TownScene()
        {
            Currentenemyindex = 0;
            Console.WriteLine("You walk over the dead bodies of your enemies as you and " + DogCharacter.GetName() + " head east");
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("//                                 One Week Later                                 //");
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("As you enter thru the imposing protective metal shell that is the cities gate you realize ");
            Console.WriteLine("you have finally arrived at your first point of delivery... the city of Lafayette.");
            Console.WriteLine("The instructions on the parcel says to bring the package to Old Ann's Church");
            Console.WriteLine("but no other directions are stated... Strange.");
            Console.ReadLine();

            //Where To Move
            string PlayerChoice = PlayerCharacter.Getinput("What will you do now to find the location?", "Ask a local shopkeeper where the church is.", "Wander around");
            if (PlayerChoice == "1")
            {
                Console.WriteLine("You walk into a charming little general store called 'Tina's Terrific Trinkets'.");
                Console.WriteLine("At the counter you see a older lady whom you assume is the stores namesake.");
                Console.WriteLine("You ask her where Old Ann's Church is.");
                Console.WriteLine("She gives you some slightly confusing directions but you eventually get what she tells you and you leave the store");
                Console.WriteLine("and start toward the church.");
                Console.ReadLine();
                Console.WriteLine("You are standing infront of a(n) imposing cathedral with a feeling of dread in your stomach.");
                Console.WriteLine("A nun walks up to you and asks for the package.");
                Console.WriteLine("You hand it to her as she hands you your money.");
                Console.WriteLine("She tells you where to go next 'Dodge City' which is east of here");
                Console.WriteLine("You bid her a good day and leve through the cities east gate");
                Console.ReadLine();
                Console.Clear();

                Console.ReadLine();
                
                //Change current scene to FightScenetwoProlouge();
                Currentscene = 5;
            }
            else if (PlayerChoice == "2")
            {
                Console.WriteLine("You wander for almost a full day before you finally find the church.");
                Console.ReadLine();
                Console.WriteLine("You are standing infront of a(n) imposing cathedral with a feeling of dread in your stomach.");
                Console.WriteLine("A nun walks up to you and asks for the package.");
                Console.WriteLine("You hand it to her as she hands you your money.");
                Console.WriteLine("She tells you where to go next 'Dodge City' which is east of here");
                Console.WriteLine("You bid her a good day and leve through the cities east gate");
                Console.ReadLine();
                Console.Clear();

                Console.ReadLine();
                
                //Change current scene to FightScenetwoProlouge();
                Currentscene = 5;
            }
            else
            {
                Console.WriteLine("Error");
                Console.ReadKey(true);
                Console.WriteLine(">");
            }
        }
        //You fail
        void FightingFailurescene()
        {
            Console.Clear();
            Console.WriteLine("As you turn away from the bodies feel something suddenly strike the back of your head");
            Console.WriteLine("and before you know it everything goes black.");
            PlayerCharacter.TakeCurrentMoney();
            PlayerCharacter.GetCurrentMoney();
            Console.ReadLine();
            Console.WriteLine("The End");
            Console.ReadLine();

            //Change current scene to GameOverScene();
            Currentscene = 4;
        }
        //A Prolouge To The Fight Scene
        void FightSceneProlouge()
        {
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("//                                 Eight Hours Later                                 //");
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("As you walk away from the caravan you hear 4 sets of feet shuffling behind you.");
            Console.WriteLine("You turn around to see a twitching miserable mess of a person coming toward you.");
            Console.WriteLine("To the left of the Crazed Bandit is a very well dressed induvidual with knuckles wrapped in wire.");
            Console.WriteLine("And to the right of the Crazy Bandit is a large mutated gator with a saw shaped mohawk that looks deadly.");
            Console.ReadLine();
            Console.Clear();
            
            //Change current scene to FightingScene();
            Currentscene = 6;
        }

        //This is the preamble to fight scene 2
        void FightScenetwoProlouge()
        {
            CrazedBandit.Heal(2000f);
            Gatorsaw.Heal(2000f);
            SaneBandit.Heal(2000f);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("//                                 Eight Hours Later                                 //");
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("As you walk away from the City you hear 4 sets of feet shuffling behind you.");
            Console.WriteLine("You turn around to see a twitching miserable mess of a person coming toward you.");
            Console.WriteLine("To the left of the Crazed Bandit is a very well dressed induvidual with knuckles wrapped in wire.");
            Console.WriteLine("And to the right of the Crazy Bandit is a large mutated gator with a saw shaped mohawk that looks deadly.");
            Console.ReadLine();
            Console.Clear();

            //Change current scene to FightSceneTwo();
            Currentscene = 11;
            
        }

        //Game Over Scene 
        void GameOverScene()
        {
            string Playerchoice = PlayerCharacter.Getinput("Would You like to start over?", " Yes", " No");

            if (Playerchoice == "1")
            {
                //Change current scene to IntroScene();
                Currentscene = 0;
            }
            else if (Playerchoice == "2")
            {
                GameOver = true;
            }
            else
            {
                Console.WriteLine("Error");
                Console.ReadKey(true);
                Console.WriteLine(">");
            }
        }

        //Fight Scene
        void FightingScene()
        {
            Fight(ref Enemies [Currentenemyindex]);

            if (Enemies[Currentenemyindex].GetHealth() <= 0 || PlayerCharacter.GetHealth() <= 0)
            {
                //Change current scene to WinGameScene();
                Currentscene = 8;
            }

        }
        //Scene where you fail
        void FightingScenetwo()
        {
            Fight(ref Enemies [Currentenemyindex]);

            if (Enemies[Currentenemyindex].GetHealth() <= 0 || PlayerCharacter.GetHealth() <= 0)
            {
                //Change current scene to FightingFailurescene();
                Currentscene = 10;
            }

        }

        





        //Fight Function
        void Fight(ref Character enemy)
        {
            DogCharacter.PrintStats();
            PlayerCharacter.PrintStats();
            enemy.PrintStats();

            string battlechoice = PlayerCharacter.Getinput("How Will You Fight Back?", "Attack", "Run Away");
            
            if (battlechoice == "1")
            {
                enemy.takedamage(PlayerCharacter.GetDamage());
                DogCharacter.Attack(enemy);
                Console.WriteLine("You hit the " + enemy.GetName());
                Console.WriteLine("Your dog " + DogCharacter.GetName() + " Bites the " + enemy.GetName() + " once.");
                Console.ReadLine();
                Console.WriteLine("Your dog " + DogCharacter.GetName() + " Mauls the " + enemy.GetName() + " with his claws.");

                if (enemy.GetHealth() <= 0)
                {
                    return;
                }
            }
            
            else if (battlechoice == "2")
            {
                Console.WriteLine("As you turned to run away the " + enemy.GetName() + " hit you in the back dealing 20 times sneak damage");
                PlayerCharacter.takedamage(enemy.GetDamage() * 50000f);
                

                if (PlayerCharacter.GetHealth() <= 0)
                {
                    //Change current scene to EndGameScene();
                    Currentscene = 7;
                }
            }
            else
            {
                Console.WriteLine("Error");
                Console.ReadKey(true);
                Console.WriteLine(">");
            }

            Console.WriteLine(enemy.GetName() + " attacks " + PlayerCharacter.GetName() + " with a weapon." );
            PlayerCharacter.takedamage(enemy.GetDamage());
            Console.ReadKey(true);


        }



        //Scene to change weapon
        void ChangeWeaponscene()
        {
            Console.Clear();
            string WeaponChoice = PlayerCharacter.Getinput("Which weapon do you want to switch to?", "Revolver", "Hammer");

            if (WeaponChoice == "1")
            {
                Console.WriteLine("                         `/\\\r\n                    ____/ /\r\n     _             / ___ \\\r\n     \\\\_!_________(_/_/ \\ \\\r\n     <#|=====|______ / /__/\r\n    / C|=====|---' \\__/\r\n   /   |-|-|~\r\n  /    /---'\r\n /    /\r\n|_____|");
                Console.WriteLine("You chose the revolver");
                Console.ReadLine();
                PlayerCharacter.EquipWeapon(0);
                //Change current scene to BreakScene();
                Currentscene = 1;


            }
            else if (WeaponChoice == "2")
            {
                Console.WriteLine("       T                                    \\`.    T\r\n       |    T     .--------------.___________) \\   |    T\r\n       !    |     |//////////////|___________[ ]   !  T |\r\n            !     `--------------'           ) (      | !\r\n                                         mn  '-'      !");
                Console.WriteLine("You chose the hammer");
                Console.ReadLine();
                PlayerCharacter.EquipWeapon(1);
                //Change current scene to BreakScene();
                Currentscene = 1;
            }
        }

        //Endgame Scene
        void EndGamescene()
        {
            string Playerchoice = PlayerCharacter.Getinput("You are dead... restart?", " Yes", " No");

            if (Playerchoice == "1")
            {
                //Change current scene to IntroScene();
                Currentscene = 0;
            }
            else if (Playerchoice == "2")
            {
                GameOver = true;
            }
        }
        
        //Winning Scene
        void WinGamescene()
        {
            if (PlayerCharacter.GetHealth() > 0 && Enemies[Currentenemyindex].GetHealth() <= 0)
            {
                Console.WriteLine("The Winner Is: " + PlayerCharacter.GetName());
                Currentscene = 6;
                Currentenemyindex++;
                if (Currentenemyindex >= Enemies.Length)
                {
                    //Change current scene to TownScene();
                    Currentscene = 2;
                }
            }
            else if (Enemies[Currentenemyindex].GetHealth() > 0 && PlayerCharacter.GetHealth() <= 0)
            {
                Console.WriteLine("The Winner Is: " + Enemies[Currentenemyindex].GetName());

                //Change current scene to EndGameScene();
                Currentscene = 7;
            }
            Console.ReadKey(true);
            Console.Clear();
        }

        void Start()
        {
            //Enemy Weapons


            Weapon RustyBoard;
            RustyBoard.WeaponName = "Rusty Board";
            RustyBoard.WeaponDamage = 20f;

            Weapon Headsaw;
            Headsaw.WeaponName = "Headsaw";
            Headsaw.WeaponDamage = 100f;

            Weapon BarbedHands;
            BarbedHands.WeaponName = "Barbed Wire Hands";
            BarbedHands.WeaponDamage = 25f;

            Weapon Metalteeth;
            Metalteeth.WeaponName = "Metalteeth";
            Metalteeth.WeaponDamage = 2500f;

            //Enemies

            CrazedBandit = new Character("Crazed Bandit", 10f, 34f, BarbedHands, 841f);

            Gatorsaw = new Character("Gatorsaw", 46f, 34f, Headsaw, 841f);

            SaneBandit = new Character("Sane Bandit", 10f, 34f, RustyBoard, 841f);

            Enemies = new Character[3] { CrazedBandit, Gatorsaw, SaneBandit };

            //Heroes

            DogCharacter = new Dog("Rex", 45f, 75f, Metalteeth, 6000f);

            PlayerCharacter = new Player("", 46000f, 450f, 45f, RustyBoard);

            //Enemy Index 

            Currentenemyindex = 0;
        }

        //Update Function
        void Update()
        {
            //selecting each scene
            if (Currentscene == 0)
            {
                IntroScene();
            }
            else if (Currentscene == 1)
            {
                BreakScene();
            }
            else if (Currentscene == 2)
            {
                TownScene();
            }
            else if (Currentscene == 3)
            {
                FightSceneProlouge();
            }
            else if (Currentscene == 4)
            {
                GameOverScene();
            }
            else if (Currentscene == 5)
            {
                FightScenetwoProlouge();
            }
            else if (Currentscene == 6)
            {
                FightingScene();
            }
            else if (Currentscene == 7)
            {
                EndGamescene();
            }
            else if (Currentscene == 8)
            {
                WinGamescene();
            }
            else if (Currentscene == 9)
            {
                ChangeWeaponscene();
            }
            else if (Currentscene == 10)
            {
                FightingFailurescene();

            }
            else if (Currentscene == 11)
            {
                FightingScenetwo();
            }
        }

        //Ending Message
        void End()
        {
            Console.WriteLine("Thank you for playing");
        }

        //Starting The Actual Game Here
        public void Run()
        {

            Start();

            while (GameOver == false)
            {

                Update();

            }

            End();

        }
    }
}
