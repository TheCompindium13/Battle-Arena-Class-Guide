﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloDungeon
{
    internal class Character
    {

        //Variables
        private string _name;
        private float _damage;
        private float _defense;
        private Weapon _currentweapon;
        private float _health;




        //Void to Print Status
        public virtual void PrintStats()
        {
            Console.WriteLine("Name: " + _name);
            Console.WriteLine("Damage: " + _damage);
            Console.WriteLine("Defense: " + _defense);
            Console.WriteLine("Health: " + _health);
            Console.WriteLine("Held Weapon: " + _currentweapon.WeaponName);
        }

        public Character()
        {
            _name = "";
            _health = 0f;
            _damage = 0f;
            _defense = 0f;

        }


        //Set Charater Paramater
        public Character(string name, float damage, float defense, Weapon currentweapon, float health)
        {
            _name = name;
            _damage = damage;
            _defense = defense;
            _currentweapon = currentweapon;
            _health = health;
        }

        //The Set of Get Variables That Allow the Private Factors to Be Used
        public Weapon GetCurrentWeapon()
        {
            return _currentweapon;
        }

        public float GetHealth()
        {
            return _health;
        }

        public float GetDamage()
        {
            return _damage;
        }
        public float GetDefense()
        {
            return _defense;
        }
        public void SetCurrentWeapon(Weapon weapon)
        {
            _currentweapon = weapon;
        }
        public string GetName()
        {
            return _name;
        }
        //Basic set function used to set the name of the player character
        public void SetName(string name)
        {
            _name = name;
        }
        //Ability to take damage/do damage
        public void takedamage(float damage)
        {
            _health -= damage - GetDefense();
        }
        public virtual void Attack(Character foe)
        {
            foe.takedamage(GetDamage());
        }
        public float Heal(float healamount)
        {
            _health = healamount;


            return _health;
        }
        
    }
}
