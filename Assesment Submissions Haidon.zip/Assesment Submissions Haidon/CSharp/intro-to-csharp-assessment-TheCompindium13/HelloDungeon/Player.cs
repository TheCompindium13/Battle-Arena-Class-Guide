﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HelloDungeon
{
    internal class Player : Character
    {
        //Basic stats
        private float _money = 50765f;
        private string _playerchoice;

        //Player Weapons
        Weapon _Revolver;
        Weapon _Hammer;
        Weapon[] _weapons;
        int _currentweaponindex;

        //This allows me to use the paramaters in character stats to be used for a player character.
        public Player(string name, float health, float damage, float defense, Weapon currentweapon) : base(name, damage, defense, currentweapon, health)
        {

            InitializedWeapons();
            _playerchoice = "";

        }

        //initialized weapons so that they could be used in the equip weapons
        public void InitializedWeapons()
        {
            _Revolver.WeaponName = "Revolving Door";
            _Revolver.WeaponDamage = 999f;

            _Hammer.WeaponName = "Hammer";
            _Hammer.WeaponDamage = 9999f;

            _weapons = new Weapon[2] {_Revolver, _Hammer};
        }

        //Function that enables the ability to equip a current weapon
        public void EquipWeapon(int index)
        {
            SetCurrentWeapon(_weapons[index]);
        }
        
        //Overrode Printstats
        public override void PrintStats()
        {
            base.PrintStats();
            Console.WriteLine("Capcoins: " + _money);
        }
        public float GetCurrentMoney()
        {
            return _money;
        }

        public void TakeCurrentMoney()
        {
            _money = 0f;
        }
        //Getting The Input One Prompt, Four Options.
        public string Getinput(string prompt, string option1, string option2, string option3, string option4)
        {
            _playerchoice = "";

            Console.WriteLine(prompt);
            Console.WriteLine("1. " + option1);
            Console.WriteLine("2. " + option2);
            Console.WriteLine("3. " + option3);
            Console.WriteLine("4. " + option4);

            _playerchoice = Console.ReadLine();

            return _playerchoice;

        }
        
        //Getting The Input One Prompt, Two Options.
        public string Getinput(string prompt, string option1, string option2)
        {
            _playerchoice = "";

            Console.WriteLine(prompt);
            Console.WriteLine("1. " + option1);
            Console.WriteLine("2. " + option2);

            _playerchoice = Console.ReadLine();

            return _playerchoice;

        }


    }
}
