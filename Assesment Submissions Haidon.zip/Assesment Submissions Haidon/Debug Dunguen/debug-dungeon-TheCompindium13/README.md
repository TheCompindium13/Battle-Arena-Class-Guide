# HelloDungeon

Debug the program so that it runs as intended. Included is a builds folder with a folder called "v1.1". Inside is the executable to use as a reference.
There is also a reference build on the release page: https://github.com/LodisAIE/DebugDungeon/releases/tag/v1.0
