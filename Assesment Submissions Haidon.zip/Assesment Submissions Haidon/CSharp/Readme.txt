How to Play:

Please Play in FullScreen

Press enter when game loads up

When prompted press numbers 1-6.

You can exit by entering the number corresponding to the number next to end game.
Game is over when it asks you to restart.