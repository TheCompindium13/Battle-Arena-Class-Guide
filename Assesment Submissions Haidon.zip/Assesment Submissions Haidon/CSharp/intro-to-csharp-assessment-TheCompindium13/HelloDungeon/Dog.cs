﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HelloDungeon
{
    internal class Dog : Character
    {
        //dog weapon struct is created here
        private Weapon _Claws;


        //dog struct is created here
        public Dog(string name, float damage, float defense, Weapon currentweapon, float health) : base(name, damage, defense, currentweapon, health)
        {
            InitializedDogWeapon();
        
        }

        //The dog specific weapon
        public void InitializedDogWeapon()
        {
            _Claws.WeaponName = "Claws";
            _Claws.WeaponDamage = 500f;
        }

        //Print stats override
        public override void PrintStats()
        {
            base.PrintStats();
            Console.WriteLine("Second Weapon: " + _Claws.WeaponName);
        }

        //override for attack so dog attacks with two different attacks
        public override void Attack(Character foe)
        {
            foe.takedamage(GetDamage());
            foe.takedamage(GetDamage() + _Claws.WeaponDamage);
        }
    }
}
