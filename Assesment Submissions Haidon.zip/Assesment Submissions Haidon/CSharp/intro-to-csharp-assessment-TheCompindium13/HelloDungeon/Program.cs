﻿using System;

namespace HelloDungeon
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a new instance of Game
            Game game = new Game();

            //Run the Game
            game.Run();
        }
    }
}